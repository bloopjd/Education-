
  function openR() {
  var url = "https://pgi-oejoie-qhoifhao-igtehaoeith.hop.sh/";
  if (window.self === window.top && url) {
    var win = window.open();
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    var iframe = win.document.createElement('iframe');
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.margin = '0';
    iframe.src = url;

    iframe.addEventListener('unload', function(event) {
      event.preventDefault();
    });

    iframe.setAttribute("sandbox", "allow-scripts allow-forms allow-pointer-lock allow-same-origin");
    iframe.setAttribute("allowfullscreen", "");

    win.document.head.innerHTML += '<link rel="shortcut icon" href="https://thecommandragon.repl.co/images/classes.png" type="image/x-icon">';
    win.document.title = "Google Classroom";

    win.document.body.appendChild(iframe);

  }
}


  function openS() {
  var url = "https://0.00z.us";
  if (window.self === window.top && url) {
    var win = window.open();
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    var iframe = win.document.createElement('iframe');
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.margin = '0';
    iframe.src = url;

    iframe.addEventListener('unload', function(event) {
      event.preventDefault();
    });

    iframe.setAttribute("sandbox", "allow-scripts allow-forms allow-pointer-lock allow-same-origin");
    iframe.setAttribute("allowfullscreen", "");

    win.document.head.innerHTML += '<link rel="shortcut icon" href="https://thecommandragon.repl.co/images/classes.png" type="image/x-icon">';
    win.document.title = "Google Classroom";

    win.document.body.appendChild(iframe);

  }
}


  function openG() {
  var url = "https://town.sciencevictory.org";
  if (window.self === window.top && url) {
    var win = window.open();
    win.document.body.style.margin = '0';
    win.document.body.style.height = '100vh';
    var iframe = win.document.createElement('iframe');
    iframe.style.border = 'none';
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.margin = '0';
    iframe.src = url;

    iframe.addEventListener('unload', function(event) {
      event.preventDefault();
    });

    iframe.setAttribute("sandbox", "allow-scripts allow-forms allow-pointer-lock allow-same-origin");
    iframe.setAttribute("allowfullscreen", "");

    win.document.head.innerHTML += '<link rel="shortcut icon" href="https://thecommandragon.repl.co/images/classes.png" type="image/x-icon">';
    win.document.title = "Google Classroom";

    win.document.body.appendChild(iframe);

  }
}

